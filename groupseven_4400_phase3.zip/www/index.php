<? require_once('lib.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Content-Style-Type" content="text/css"/>
    <link rel="stylesheet" href="index.css" type="text/css"/>
    <title>Georgia Tech Career Service System</title>
  </head>
  <body>
    <h1>
      Welcome to GTCareer
    </h1>
    <table>
      <tr>
        <td class="box">
          <h2><a href="applicant_login.php">Applicant</a></h2>
          <br />
          <p>Update your profile</p>
          <p>Search/Apply for jobs</p>
          <p>Check application status</p>
        </td>
        <td class="middleSpace">
        </td>
        <td class="box">
          <h2><a href="recruiter_login.php">Recruiter</a></h2>
          <br />
          <p>Post jobs</p>
          <p>Search for applicants</p>
          <p>Check jobs status</p>
        </td>
      </tr>
    </table>
  </body>
</html>

