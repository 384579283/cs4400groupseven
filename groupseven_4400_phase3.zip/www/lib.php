<?

session_start();

require_once('functions.php');

require_once('db.php');

$db = new Database();

kill_magic_quotes();

?>
